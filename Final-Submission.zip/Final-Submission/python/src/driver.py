# Streaming Application to read from Kafka
# This should be the driver file for your project

#Lets import the necessary libraries
import os
import sys
from pyspark.sql import SparkSession
from pyspark.sql.types import *
from pyspark.sql.functions import *
from rules.rules import *

#Lets initialize the spark session
spark = SparkSession \
        .builder \
        .appName("CreditCardFraud") \
        .getOrCreate()
spark.sparkContext.setLogLevel('ERROR')

#Reading input data from Kafka
credit_card_data = spark \
                   .readStream \
                   .format("kafka") \
                   .option("kafka.bootstrap.servers", "18.211.252.152:9092") \
                   .option("startingOffsets", "earliest") \
                   .option("failOnDataLoss", "false") \
                   .option("subscribe", "transactions-topic-verified") \
                   .load()

#Defining schema for the transactional payload data
creditSchema = StructType() \
               .add("card_id", LongType()) \
               .add("member_id", LongType()) \
               .add("amount", DoubleType()) \
               .add("pos_id", LongType()) \
               .add("postcode", IntegerType()) \
               .add("transaction_dt", StringType())

#Casting raw data as string and then we performed aliasing
credit_card_data = credit_card_data.selectExpr("cast(value as string)")
credit_card_data_stream = credit_card_data.select(from_json(col="value", schema=creditSchema).alias("credit")).select("credit.*")

#Defined an UDF for verifiying all the rules for each transaction and update lookup and master tables
verifying_rules = udf(verify_all_rules, StringType())

#Adding a new column for getting status by passing all the parameters to the above mentioned UDF
final_credit_data = credit_card_data_stream \
                    .withColumn("status", verifying_rules(credit_card_data_stream['card_id'],
                                                          credit_card_data_stream['member_id'],
                                                          credit_card_data_stream['amount'],
                                                          credit_card_data_stream['pos_id'],
                                                          credit_card_data_stream['postcode'],
                                                          credit_card_data_stream['transaction_dt']))

#Writing the final result to console
output = final_credit_data \
         .select('card_id', 'member_id', 'amount', 'pos_id', 'postcode', 'transaction_dt', 'status') \
         .writeStream \
         .outputMode("append") \
         .format("console") \
         .option("truncate", False) \
         .start()

#Informing Spark to await termination
output.awaitTermination()