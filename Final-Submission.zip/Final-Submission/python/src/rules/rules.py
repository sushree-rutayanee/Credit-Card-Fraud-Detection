# List all the functions to check for the rules
from db.dao import HBaseDao
from db.geo_map import GEO_Map
from datetime import datetime
import uuid

#Lets create the UDF functions
lookup_table = 'lookup_data_hbase'
master_table = 'card_transactions_hbase'
speed_threshold = 0.25 #in km/sec - Average speed of flight in 900 km/hr

"""
Function to verify the UCL rule
Transaction amount should be less than upper control limit (UCL)
"""
def verify_ucl(card_id, amount):
    try:
        dbdao1 = HBaseDao.get_instance()

        card_dict = dbdao1.get_data(key = str(card_id), table = lookup_table)
        card_ucl = (card_dict[b'card_data:ucl']).decode("utf-8")

        if amount < float(card_ucl):
            return True
        else:
            return False
    except Exception as e:
        raise Exception(e)

"""
Function to verify the credit score rule
Credit score of each member should be greater than 200
"""
def verify_credit_score(card_id):
    try:
        dbdao1 = HBaseDao.get_instance()

        card_dict = dbdao1.get_data(key = str(card_id), table = lookup_table)
        card_score = (card_dict[b'card_data:score']).decode("utf-8")

        if int(card_score) > 200:
            return True
        else:
            return False
    except Exception as e:
        raise Exception(e)

"""
Function to verify the zipcode distance
"""
def verify_zipcode_distance(card_id, postcode, transaction_dt):
    try:
        dbdao1 = HBaseDao.get_instance()
        dbgeo1 = GEO_Map.get_instance()

        card_dict = dbdao1.get_data(key = str(card_id), table = lookup_table)
        last_postcode = (card_dict[b'card_data:postcode']).decode("utf-8")
        last_transaction_dt = (card_dict[b'card_data:transaction_dt']).decode("utf-8")

        current_lat = dbgeo1.get_lat(str(postcode))
        current_lon = dbgeo1.get_long(str(postcode))
        previous_lat = dbgeo1.get_lat(last_postcode)
        previous_lon = dbgeo1.get_long(last_postcode)

        distance = dbgeo1.distance(lat1 = current_lat, long1 = current_lon, lat2 = previous_lat, long2 = previous_lon)

        speed = calculate_speed(distance, transaction_dt, last_transaction_dt)

        if speed < speed_threshold:
            return True
        else:
            return False

    except Exception as e:
        raise Exception(e)

"""
Function to calculate the speed from distance and transaction timestamp differentials
"""
def calculate_speed(distance, transaction_dt1, transaction_dt2):
    transaction_dt1 = datetime.strptime(transaction_dt1, '%d-%m-%Y %H:%M:%S')
    transaction_dt2 = datetime.strptime(transaction_dt2, '%d-%m-%Y %H:%M:%S')

    elapsed_time = transaction_dt1 - transaction_dt2
    elapsed_time = elapsed_time.total_seconds()

    try:
        return distance/elapsed_time
    except ZeroDivisionError:
        return 299792.458 #Speed of light

"""
Function to verify all the rules i.e. for ucl, credit score and zipcode distance
"""
def verify_all_rules(card_id, member_id, amount, pos_id, postcode, transaction_dt):
    dbdao1 = HBaseDao.get_instance()

    #We need to check if the POS transactional data is passing all the rules
    #If it passes then we need to update the lookup table and insert it in master table saying it is genuine
    #Else we need to insert in the master table saying it is fraud

    rule1 = verify_ucl(card_id, amount)
    rule2 = verify_credit_score(card_id)
    rule3 = verify_zipcode_distance(card_id, postcode, transaction_dt)

    if all([rule1, rule2, rule3]):
        status = 'GENUINE'
        dbdao1.write_data(key = str(card_id), 
                          row = {'card_data:postcode':str(postcode), 'card_data:transaction_dt':str(transaction_dt)},
                          table = lookup_table)
    else:
        status = 'FRAUD'

    new_id = str(uuid.uuid4()).replace('-', '')
    dbdao1.write_data(key = new_id, 
                      row = {'card_data1:card_id':str(card_id), 'card_data1:member_id':str(member_id), 'card_data1:amount':str(amount), 
                             'card_data1:pos_id':str(pos_id), 'card_data1:postcode':str(postcode), 'card_data1:status':str(status),
                             'card_data1:transaction_dt':str(transaction_dt)},
                      table = master_table)

    return status